import numpy as np
from leer_archivo import leer_archivo
from sigmoid import sigmoid
from signo import signo
import matplotlib.pyplot as plt


# [x,yD] = leer_archivo('Guia1/OR_trn.csv',2)
def perceptronMulticapa(x, yD, xP, yDP, capas, epocaMaxima, velocidadAprendizaje, criterioError):
    x = np.insert(x, 0, -1, axis=1)
    cantCapas = len(capas)
    constanteSigmoid = 1
    W = np.empty(cantCapas, dtype=object)
    epoca = 0
    cantErrores = 0
    errorPorcentual = 0
    erroresPorEpoca = np.zeros(epocaMaxima)
    errorCuadraticoPorEpoca = np.zeros(epocaMaxima)
    seguir = 1  # en vez del break
    # -----------------------------------------Cálculo de pesos-------------------------------------------------
    sizeEntrada = len(x[0])
    for c in range(len(capas)):
        if c == 0:  # se inicializa W para todos los patrones
            W[c] = np.random.uniform(
                -0.5, 0.5, [capas[c], sizeEntrada]
            )  # caso de primer matriz
        else:
            W[c] = np.random.uniform(-0.5, 0.5, [capas[c], capas[c - 1] + 1])#El +1 es por la entrada x_0
    while epoca < epocaMaxima and seguir == 1:  # Por época
        for n in range(len(x)):  # Por patrón
            Y = []
            # --------------------------------Propagación hacia delante-----------------------------------------
            entradas = x[n].reshape(-1,1)  # COLUMNA
            for i in range(cantCapas):  # Por capa
                salidaLineal = W[i] @ entradas #vector columna
                y = sigmoid(salidaLineal, constanteSigmoid)
                y = y.flatten().reshape(-1,1)
                Y.append(y)#El primer x[n] ya tiene el -1
                # pongo como entrada de la capa siguiente la salida y le agrego la columna de -1's
                entradas = Y[-1]
                entradas = np.insert(entradas, 0, -1).reshape(-1,1)#Se le pone el -1 a cada salida
            # Una vez calculadas
            e_j = yD[n].reshape(-1,1) - Y[-1] #Compara contra la salida final y[-1]
            deltas = []
            # ------------------------------------Propagación hacia atrás------------------------------------------
            for i in range(cantCapas - 1, -1, -1):
                derivadaFunActivacion = (
                    (1 / 2) * (Y[i] + 1) * (Y[i] - 1)
                )
                if (i == cantCapas-1):
                    deltas.insert(0,derivadaFunActivacion * e_j) #El ultimo delta es
                else:
                    #w: pesos transpuestos sin el -1
                    pesos = W[i+1]  # Obtenemos los pesos de la capa siguiente
                    w = np.transpose(pesos[:, 1:]) 
                    a = (w @ deltas[0])
                    deltas.insert(0,derivadaFunActivacion * a)
            # ------------------------------------Actualización de pesos-------------------------------------------------
            for i in range(cantCapas):
                delta_w = np.zeros_like(W[i])
                if i == 0:
                    entrada0 = x[n].reshape(-1,1)  #reshape(1,deltas[i].shape[0])
                    delta_w = velocidadAprendizaje * ( deltas[i] @ entrada0.T)
                else:
                    #Acá se agrega el -1 a las salidas ya que actúan como entradas
                    salidaSesgada = np.insert(Y[i-1], 0, -1).flatten().reshape(-1,1).T
                    delta_w = velocidadAprendizaje * (deltas[i] @ salidaSesgada)
                W[i] = W[i] + delta_w
        # -------------------------------------Ver error y criterio de parada-------------------------------------------------
        cantErrores = 0
        errorCuadratico = 0
        for k in range(len(x)):
            Y = []
            entradas = x[k].reshape(-1,1)  # COLUMNA
            for i in range(cantCapas):  # Por capa
                salidaLineal = W[i] @ entradas #vector columna
                y = sigmoid(salidaLineal, constanteSigmoid)
                y = y.flatten().reshape(-1,1)
                Y.append(y)#El primer x[n] ya tiene el -1
                # pongo como entrada de la capa siguiente la salida y le agrego la columna de -1's
                entradas = Y[-1]
                entradas = np.insert(entradas, 0, -1).reshape(-1,1)#Se le pone el -1 a cada salida
            error = yD[k] - signo(Y[-1])
            #Poner para salida multidimensionall sin signo
            if np.any(error != 0):
                cantErrores += 1
            errorCuadratico += (yD[k] - Y[-1])**2
        errorCuadratico = errorCuadratico/len(x)
        errorPorcentual = cantErrores / len(x)
        erroresPorEpoca[epoca] = errorPorcentual
        errorCuadraticoPorEpoca[epoca] = errorCuadratico
        if errorPorcentual < criterioError:  # criterio de parada
            seguir = 0
        epoca += 1

    print("Cantidad de épocas: ", epoca)
    cantEpocasTr = epoca
    print("Cantidad de errores entrenamiento: ", cantErrores)
    cantErroresTr = cantErrores
    print("Error porcentual entrenamiento: ", errorPorcentual)
    errorPorcentualTr = errorPorcentual
    plt.plot(errorCuadraticoPorEpoca)
    plt.show()
    
    # ---------------------------------------------Datos de prueba-------------------------------------------------
    # xP = np.insert(xP, 0, -1, axis=1)  # meto una columna de -1's
    # cantErroresPrueba = 0
    # errorCuadraticoPrueba = 0
    # for n in range(len(xP)):
    #     entradas = x[n].reshape(-1,1)
    #     yt = np.empty(cantCapas, dtype=object)
    #     for i in range(cantCapas):  # Por cada capa
    #         salidaLineal = W[i] @ entradas
    #         yt[i] = sigmoid(salidaLineal, constanteSigmoid)
    #         entradas = yt[i]
    #         entradas = np.insert(entradas, 0, -1, axis=0)
    #     error = yD[n] - signo(yt[-1])
    #     errorCuadraticoPrueba = (yD[n] - yt[-1])**2
    #     if np.any(error != 0):
    #         cantErroresPrueba += 1

    # errorPorcentualPrueba = cantErroresPrueba / len(xP)
    # print("Error cuadrático: ", errorCuadraticoPrueba)
    # print("Cantidad de errores de testeo: ", cantErroresPrueba)
    # print("Error porcentual testeo: ", errorPorcentualPrueba)
    return [
        cantEpocasTr,
        cantErroresTr,
        errorPorcentualTr,
        cantErroresPrueba,
        errorPorcentualPrueba,
    ]
